package com.utn.utnApiRest.repositories;

import com.utn.utnApiRest.entities.Autor;
import org.springframework.stereotype.Repository;

@Repository
public interface AutorRepository extends BaseRepository<Autor, Long> {
}
