# Tp4 Api Rest Paginado

Trabajo Practico

# Carpeta Build con Libs:

https://drive.google.com/drive/folders/1x-mYcWuWIQSMk3PqxvRIx_LU6o0ANDoT

# Captura Render (live)

Deploy: https://tp4paginado.onrender.com

![Captura](https://github.com/JoaquinMS/Tp4Paginado/assets/118018407/d5322b26-9672-4c0b-8672-b9a9fe0469d9)

# Diagrama de clases

![Captura](https://github.com/JoaquinMS/Tp4-ApiRest/assets/118018407/b8c5635d-a23a-475b-8d20-78e3bf84c9e6)



